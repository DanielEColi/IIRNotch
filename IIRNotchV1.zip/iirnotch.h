#ifndef __IIR_NOTCH_H__
#define __IIR_NOTCH_H__

#include <math.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif


#define		AZ_PI				(3.1415926f)
#define		AZ_SAMPLE_RATE		(1024)
#define		AZ_NOTCH_RATE		(60)
#define     AZ_FREQ_NORM(f,fs)	((double)f/(fs/2.0))
#define		AZ_NOTCH_W0			(AZ_FREQ_NORM(AZ_NOTCH_RATE,AZ_SAMPLE_RATE))


/* ============= Filter declaration code=============*/
#define		AZ_CH_NUM				(12)
#define		AZ_NOTCH_SIZE			(3)
static float fCoefNum[AZ_CH_NUM][AZ_NOTCH_SIZE];
static float fCoefDen[AZ_CH_NUM][AZ_NOTCH_SIZE];
static float fNotchBuf[AZ_CH_NUM][AZ_NOTCH_SIZE];
void DesignNotch(float Wo,float BW,float Ab,float *num,float *den );
void InitNotchByChannel(short ch,float BW);
int IIRNotchFilter(short ch,int xn);

#ifdef __cplusplus
}

#endif

#endif
