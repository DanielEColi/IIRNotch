#include <stdio.h>
#include <stdlib.h>
#include "iirnotch.h"


FILE *pFile;
void main(void)
{
	int i;
	int val,y1,y2,y3;

	pFile = fopen("testSignal.txt","wt");
	if (pFile==NULL)
	{
		printf("Fail!\n");
		return;
	}
	else printf("PASS!\n");

	InitNotchByChannel(0,(float)AZ_FREQ_NORM(2.0,AZ_SAMPLE_RATE));
	InitNotchByChannel(1,(float)AZ_FREQ_NORM(2.0,AZ_SAMPLE_RATE));
	InitNotchByChannel(11,(float)AZ_FREQ_NORM(2.0,AZ_SAMPLE_RATE));
	for (i=0;i<AZ_SAMPLE_RATE*5;i++)
	{
		val = (int)(2e4*cos((double)(2*AZ_PI*1*i)/AZ_SAMPLE_RATE)+1e4*cos((double)(2*AZ_PI*59.8*i)/AZ_SAMPLE_RATE));
		y1 = IIRNotchFilter(0,val);
		val = (int)(2e4*cos((double)(2*AZ_PI*1*i)/AZ_SAMPLE_RATE)+1e4*cos((double)(2*AZ_PI*60*i)/AZ_SAMPLE_RATE));
		y2 = IIRNotchFilter(1,val);
		val = (int)(2e4*cos((double)(2*AZ_PI*1*i)/AZ_SAMPLE_RATE)+1e4*cos((double)(2*AZ_PI*60.2*i)/AZ_SAMPLE_RATE));
		y3 = IIRNotchFilter(11,val);
		//fprintf(pFile,"%f\t%f\t%f\t%f\n",val,y1,y2,y3);
		fprintf(pFile,"%d\t%d\t%d\t%d\n",val,y1,y2,y3);
	}

	fclose(pFile);
// 	getchar();

}
